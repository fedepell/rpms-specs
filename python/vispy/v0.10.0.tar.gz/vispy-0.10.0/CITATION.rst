How do I cite VisPy?
--------------------

VisPy's source code is published on Zenodo.org:

https://zenodo.org/record/4321173

DOI and citing information can be found on the right side of the Zenodo page.
Each VisPy release has its own DOI as well as the project as a whole. The
overall VisPy DOI URL is:

https://doi.org/10.5281/zenodo.592490