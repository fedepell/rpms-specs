=======
Credits
=======

Development Lead
----------------

* Jonas Berg https://github.com/pyhys

Contributors
------------

Significant contributions by:

* Aaron LaLonde
* Andres Ulloa
* Angelo Compagnucci
* Asier Abalos
* Austin Stover
* Dino
* Dominik Socha
* Edgar Bonet
* Edwin van den Oetelaar
* Github user: draput
* Github user: gnbl
* Github user: mrrs6
* Github user: noafterglow
* Jan Breuer (Github user: j123b567)
* Luca Di Gregorio
* Matthias Bolte
* Michael Penza
* Peter
* Russ Garrett
* Yurij Z (Github user: zyura)

