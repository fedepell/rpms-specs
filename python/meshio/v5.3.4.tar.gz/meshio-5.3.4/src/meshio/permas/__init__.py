from ._permas import read, write

__all__ = ["read", "write"]
