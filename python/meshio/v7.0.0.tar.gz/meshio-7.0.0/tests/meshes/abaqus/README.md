* `UUea.inp`: From http://www-h.eng.cam.ac.uk/help/programs/fe/abaqus/faq68/txt/UUea.inp.txt
* `nle1xf3c.inp`: From https://abaqus-docs.mit.edu/2017/English/SIMAINPRefResources/nle1xf3c.inp
