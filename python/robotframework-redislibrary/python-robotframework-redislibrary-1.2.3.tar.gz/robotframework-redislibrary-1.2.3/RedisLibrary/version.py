# Update this before release
VERSION = "1.2.3"
